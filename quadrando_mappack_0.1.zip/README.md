# SMZ3 tracker pack
This is a map & item tracker for the [Super Metroid + A Link to the Past Combo randomizer](https://samus.link) to use with [EmoTracker](https://emotracker.net).  It has full item and map tracking support, as well as autotracking on supported platforms.

Ninban has decided to no longer work on the tracker, so I (Dorkmaster Flek) am taking over this project.  I can be found in the EmoTracker discord as well as the ALttP + SM Combo Randomizer discord for any questions, issues or bugs!

## Thanks
Gilgatex - The original author of this pack.  Without him, none of this would be possible so huge thanks!

Ninban - Took over managing this pack after Gilgatex until now.  Many thanks!
