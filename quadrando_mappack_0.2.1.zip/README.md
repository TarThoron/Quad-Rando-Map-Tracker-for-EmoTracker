# Quad Rando tracker pack
This is a map & item tracker for the [Super Metroid, A Link to the Past, Legend of Zelda, and Metroid Combo randomizer](https://quad.beta.samus.link) to use with [EmoTracker](https://emotracker.net).

## Thanks
Gilgatex - The original author of SMZ3 pack which this pack uses for Super Metroid and Zelda 3.
Ninban - Took over managing SMZ3 pack after Gilgatex, until Dorkmaster Fleck took over.
Dorkmaster Fleck - Current manager of the SMZ3 pack, who matched SMZ3 logic exactly, and added autotracking.
dudude dude - author of the Z1 pack that provided the overworld map data and several graphics to this pack
fouton - provided the Any Key counter code, which was also reused for the Triforce Hunt counter
JSR_ - provided invaluable info on z1 combat and enemy vulnerabilities
The Quad Rando and EmoTracker communities in general, always being willing to answer questions that come up
Total - For making Quad Rando and SMZ3 in the first place
